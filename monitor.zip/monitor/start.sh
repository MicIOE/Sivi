ls -l > /home/pi/a.txt
cd /home/pi/monitor
java -classpath . -jar monitor.jar >/home/pi/aajava.txt &
